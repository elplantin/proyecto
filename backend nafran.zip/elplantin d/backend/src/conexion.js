const mysql = require("mysql2")
const con = mysql.createConnection({
    host:"localhost",
    user: "root",
    password: "",
    database: "elplantin"
})

con.connect((error)=>{
    if (error){
        console.log("Error al conectarse con la base de datos",error.message)
    }
    else
    {
        console.log("conectado con la base de datos")
        
    }
});

module.exports= con;
