const express = require("express")
const base = require("./conexion.js")
const con = base;
const app = express();
const cookieparser = require("cookie-parser")


//login 
app.use(express.json());

app.listen(8000);

console.log("Servidor inicado en el http://localhost:8000")

app.post("/login",(req,res)=>{
    let mail = req.body.mail
    let password = req.body.password

    const consulta = `SELECT * FROM usuarios 
                      WHERE mail = '${mail}' AND contrasenia = '${password}' AND baja = 0;`

        con.query(consulta,(error,result)=>{

        if (error){
            console.log("error, la consulta no se pudo realizar",error.message)
            res.status(500).json({
                "message" : "No se pudo realizar la accion"
            })
        }
        else
        {
            const datoDeDB = result[0].id;
            res.cookie("controlid",datoDeDB);
            console.log("Consulta realizada correctamente")
            console.log("La Cookie con el dato fue creado correctamente")
            res.status(200).json(result[0]);
        }
    });                      
})
//crear usuario
app.get("/register-usuario",(req,res)=>{
    const mail = req.body.mail
    const password = req.body.password

    const consulta = `INSERT INTO usuarios(mail,contrasenia,vendedor)
                     VALUES ('${mail}','${password}','0')`;
    con.query(consulta,(error,result)=>{
        if (error){
            console.log("error, la consulta no se pudo realizar",error.message)
            res.status(500).json({
                "mensaje": "No se pudo realizar el registro en este momento",
                "mensaje2": "intentelo mas tarde"
            });
        
        }
        else
        {
            console.log("El proceso de registro se pudo realizar satisfactoriamente")
            res.status(200).json({
                "mensaje": "Cuenta Registrada, Bienvenido"
            });
        }
    })

})
// Crear publicacion
app.put("/crear-publicacion",(req,res)=>{
    const titulo = req.body.titulo
    const precio = req.body.precio
    const descripcion = req.body.descripcion
    const cantidad = req.body.cantidad
    const idvendedor = req.cookies.controlid
    const imagen = req.body.imagen

    const consulta = `INSERT INTO publicaciones
                     (titulo,precio,descripcion,cantidad,id_vendedor,mostrar,borrar,imagen)
                     VALUES ('${titulo}','${precio}','${descripcion}','${cantidad}','${idvendedor}','1','0','${imagen});`
    con.query(consulta,(error,result)=>{
        if (error){
            console.log("Error en la generacion de publicaciones",error.message)
            result.status(200).json({
                "mensaje": "No se pudo realizar la accion deseada",
                "mensaje2": "intentelo de nueva mas tarde"
            })
        }
        else
        {
            console.log("Proceso de generacion de bases de datos")
            result.status(200).json({
                "mensaje": "La publicacion fue creada satisfactoriamente"
            })
        }
    })
})