CREATE DATABASE IF NOT EXISTS elplantin;
USE elplantin;
CREATE TABLE IF NOT EXISTS usuarios(
    id INT AUTO_INCREMENT NOT NULL,
    mail VARCHAR(256) NOT NULL,
    contrasenia VARCHAR(16) NOT NULL,
    direccion VARCHAR(2000) NULL,
    vendedor INT NOT NULL,
    cbu VARCHAR(21) NULL,
    logo VARCHAR(500) NULL,
    descripcion VARCHAR(2000) NULL, 
    baja INT NOT NULL,
    motivo VARCHAR(2000) NULL,
    PRIMARY KEY(id)
);
CREATE TABLE IF NOT EXISTS publicaciones(
    id INT AUTO_INCREMENT NOT NULL,
    id_vendedor INT NOT NULL,
    tituLo VARCHAR(100) NOT NULL,
    descripcion VARCHAR(500) NOT NULL,
    imagen VARCHAR(200) NOT NULL,
    precio INT NOT NULL,
    cantidad INT NOT NULL,
    mostrar INT NOT NULL,
    borrar INT NOT NULL,
    PRIMARY KEY(id)
);
